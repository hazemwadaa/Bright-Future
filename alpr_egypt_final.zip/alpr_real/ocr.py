"""
OCR Module — Egyptian Plate Aware
===================================
Handles Egyptian license plates which use:
  - Eastern Arabic numerals (٠١٢٣٤٥٦٧٨٩) on the LEFT zone
  - Arabic letters on the RIGHT zone
  - "EGYPT / مصر" header on top

Strategy:
  1. Split plate into header / digit-zone / letter-zone
  2. Run Tesseract digit-only on digit zone (upscaled)
  3. Run Tesseract on full plate for any Latin chars
  4. Return best composite result + image hash for whitelist matching
"""

import re
import cv2
import hashlib
import numpy as np
import pytesseract
from dataclasses import dataclass, field
from collections import Counter


_EA_FIX = str.maketrans({
    'o': '0', 'O': '0', 'l': '1', 'I': '1', 'i': '1',
    'z': '2', 'Z': '2', 'e': '3', 'E': '3', 'q': '9', 'Q': '9',
})

_PSMS = [7, 6, 8, 13, 11]


@dataclass
class OCRResult:
    text:       str
    confidence: float
    engine:     str
    plate_hash: str = ""
    raw_reads:  list = field(default_factory=list)


def _upscale(img, target_w=320):
    h, w = img.shape[:2]
    if w == 0:
        return img
    scale = max(1, int(target_w / w))
    return cv2.resize(img, (w * scale, h * scale),
                      interpolation=cv2.INTER_LANCZOS4)


def _preprocess_variants(gray):
    variants = []
    _, v1 = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    variants.append(v1)
    variants.append(cv2.bitwise_not(v1))
    blur = cv2.GaussianBlur(gray, (3, 3), 0)
    v3 = cv2.adaptiveThreshold(blur, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                cv2.THRESH_BINARY, 11, 3)
    variants.append(v3)
    clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(4, 4))
    enhanced = clahe.apply(gray)
    _, v4 = cv2.threshold(enhanced, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    variants.append(v4)
    return variants


def _find_plate_body(roi_bgr):
    h, w = roi_bgr.shape[:2]
    hsv = cv2.cvtColor(roi_bgr, cv2.COLOR_BGR2HSV)
    blue_mask = cv2.inRange(hsv, (90, 40, 40), (135, 255, 255))
    blue_row_counts = blue_mask.sum(axis=1) / 255
    header_rows = np.where(blue_row_counts > w * 0.25)[0]
    if len(header_rows) > 0:
        body_start = int(header_rows[-1]) + 2
    else:
        body_start = int(h * 0.30)
    body_start = min(body_start, int(h * 0.60))
    return roi_bgr[body_start:, :]


def _tess_read(img_gray, psm, whitelist=""):
    config = f"--psm {psm} --oem 3"
    if whitelist:
        config += f" -c tessedit_char_whitelist={whitelist}"
    try:
        data = pytesseract.image_to_data(
            img_gray, config=config, output_type=pytesseract.Output.DICT)
        texts = [str(t).upper().strip() for t in data["text"] if str(t).strip()]
        confs = [float(c) for c, t in zip(data["conf"], data["text"])
                 if str(t).strip() and float(c) > 0]
        text = "".join(texts).translate(_EA_FIX)
        text = re.sub(r"[^A-Z0-9]", "", text)
        conf = float(np.mean(confs)) if confs else 0.0
        return text, conf
    except Exception:
        return "", 0.0


def _score(text, conf):
    if not text:
        return 0.0
    digit_runs = re.findall(r'\d+', text)
    longest = max((len(r) for r in digit_runs), default=0)
    length_bonus = min(len(text) / 7.0, 1.0)
    run_bonus = min(longest / 4.0, 1.0)
    return (conf * 0.01) * (1.0 + length_bonus + run_bonus)


def _plate_hash(roi):
    small = cv2.resize(roi, (32, 16))
    gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY) if small.ndim == 3 else small
    return hashlib.md5(gray.tobytes()).hexdigest()[:12]


def read_plate(roi):
    if roi is None or roi.size == 0:
        return OCRResult("", 0.0, "none")

    p_hash = _plate_hash(roi)
    h, w = roi.shape[:2]

    if w < 150:
        scale = max(2, int(300 / max(w, 1)))
        roi = cv2.resize(roi, (w * scale, h * scale),
                         interpolation=cv2.INTER_LANCZOS4)
        h, w = roi.shape[:2]

    body = _find_plate_body(roi)
    if body.shape[0] < 8:
        body = roi

    bh, bw = body.shape[:2]
    digit_zone = body[:, :int(bw * 0.55)]
    full_body = body
    candidates = []

    # Digit zone — numbers only
    dz_up = _upscale(digit_zone, target_w=280)
    dz_gray = cv2.cvtColor(dz_up, cv2.COLOR_BGR2GRAY) if dz_up.ndim == 3 else dz_up
    for variant in _preprocess_variants(dz_gray):
        for psm in [7, 6, 8]:
            text, conf = _tess_read(variant, psm, whitelist="0123456789")
            digits = re.sub(r"[^0-9]", "", text)
            if len(digits) >= 2:
                candidates.append((digits, _score(digits, conf), f"digit_psm{psm}"))

    # Full body — no whitelist
    fb_up = _upscale(full_body, target_w=400)
    fb_gray = cv2.cvtColor(fb_up, cv2.COLOR_BGR2GRAY) if fb_up.ndim == 3 else fb_up
    for variant in _preprocess_variants(fb_gray):
        for psm in _PSMS:
            text, conf = _tess_read(variant, psm)
            cleaned = re.sub(r"[^A-Z0-9]", "", text)
            if len(cleaned) >= 3:
                candidates.append((cleaned, _score(cleaned, conf), f"full_psm{psm}"))

    # Full original ROI
    full_gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY) if roi.ndim == 3 else roi
    for variant in _preprocess_variants(full_gray):
        text, conf = _tess_read(variant, 6)
        cleaned = re.sub(r"[^A-Z0-9]", "", text)
        if len(cleaned) >= 2:
            candidates.append((cleaned, _score(cleaned, conf), "raw_psm6"))

    if not candidates:
        return OCRResult("", 0.0, "tesseract", plate_hash=p_hash)

    candidates.sort(key=lambda x: x[1], reverse=True)
    best_text, best_score, best_engine = candidates[0]

    # Try to agree on digit sequence across top candidates
    all_texts = [c[0] for c in candidates[:5] if c[0]]
    digit_seqs = []
    for t in all_texts:
        digit_seqs.extend(re.findall(r'\d{2,}', t))
    if digit_seqs:
        best_digits = Counter(digit_seqs).most_common(1)[0][0]
        if best_digits not in best_text:
            best_text = best_digits

    return OCRResult(
        text=best_text,
        confidence=min(best_score, 1.0),
        engine=best_engine,
        plate_hash=p_hash,
        raw_reads=[c[0] for c in candidates[:5]],
    )
