# ALPR — Egyptian Plate Recognition System

## Dataset
- **2,032 images** of real Egyptian vehicles (Roboflow: alpr-spboh v1, CC BY 4.0)
- **1,830 training images** (train + valid splits merged)
- **202 test images**
- YOLO v7 format, 640×640px

## Files
```
├── app.py          Main GUI application
├── detector.py     Plate localization (HOG + SVM)
├── ocr.py          Egyptian-aware OCR (digit zone + Tesseract)
├── whitelist.py    Whitelist + gate logic + entry log
├── train.py        Training pipeline
├── alpr.spec       PyInstaller build spec
├── models/         Trained model (plate_detector.pkl)
├── whitelist/      whitelist.json
└── logs/           entry_log.csv
```

## Running
```bash
python app.py
```

## Building app.exe (Windows)
```bash
pip install pyinstaller pillow opencv-python pytesseract scikit-learn numpy
# Install Tesseract: https://github.com/UB-Mannheim/tesseract/wiki
pyinstaller alpr.spec
# Output: dist/ALPR.exe
```

## Egyptian Plate Notes
Egyptian plates use Eastern Arabic numerals (٠-٩) and Arabic letters.
The OCR uses:
1. Blue-header removal (isolates digit/letter body)
2. Digit zone extraction (left side of plate)
3. Multi-pipeline Tesseract with digit whitelist
4. Image hash fallback — whitelist plates by image fingerprint even if text is unreadable

To whitelist a plate by image: detect it in Camera tab → click "+ Add plate to whitelist"
