# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path
BASE = Path(SPECPATH)
block_cipher = None

a = Analysis(
    [str(BASE / 'app.py')],
    pathex=[str(BASE)],
    binaries=[],
    datas=[
        (str(BASE / 'whitelist'), 'whitelist'),
        (str(BASE / 'logs'),      'logs'),
        (str(BASE / 'models'),    'models'),
    ],
    hiddenimports=[
        'cv2', 'PIL', 'PIL._tkinter_finder',
        'pytesseract', 'sklearn', 'sklearn.svm',
        'sklearn.preprocessing', 'sklearn.pipeline',
        'sklearn.metrics', 'sklearn.model_selection',
        'numpy', 'detector', 'ocr', 'whitelist', 'train',
    ],
    hookspath=[],
    runtime_hooks=[],
    excludes=[],
    cipher=block_cipher,
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)
exe = EXE(
    pyz, a.scripts, a.binaries, a.zipfiles, a.datas, [],
    name='ALPR',
    debug=False,
    strip=False,
    upx=True,
    console=False,
    icon=None,
)
