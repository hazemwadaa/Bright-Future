"""
Plate Detector Module
=====================
Locates license plates in a frame using a trained HOG+SVM model.
Falls back to classical CV (Canny + contour) when no model is loaded.
"""

import cv2
import numpy as np
import pickle
import json
from pathlib import Path


# ── HOG defaults (overridden by model_meta.json if present) ──────────────────
_HOG_WIN_SIZE     = (64, 32)
_HOG_BLOCK_SIZE   = (16, 16)
_HOG_BLOCK_STRIDE = (8, 8)
_HOG_CELL_SIZE    = (8, 8)
_HOG_NBINS        = 9

# Sliding window settings
SCALES       = [1.0, 0.75, 0.5, 0.35]
STEP_X       = 16   # pixels
STEP_Y       = 12
NMS_THRESH   = 0.3
SCORE_THRESH = 0.60  # minimum plate probability


class PlateDetector:
    def __init__(self, model_path: str | None = None):
        self.pipeline    = None
        self.hog         = None
        self.win_size    = _HOG_WIN_SIZE
        self._load_model(model_path)
        self._build_hog()

    # ── Setup ────────────────────────────────────────────────────────────────
    def _load_model(self, model_path):
        if model_path and Path(model_path).exists():
            with open(model_path, "rb") as f:
                self.pipeline = pickle.load(f)
            meta_path = Path(model_path).parent / "model_meta.json"
            if meta_path.exists():
                with open(meta_path) as f:
                    meta = json.load(f)
                self.win_size = tuple(meta.get("hog_win_size", list(_HOG_WIN_SIZE)))
            print(f"[Detector] Model loaded from {model_path}")
        else:
            print("[Detector] No model found — using classical CV fallback.")

    def _build_hog(self):
        self.hog = cv2.HOGDescriptor(
            self.win_size, _HOG_BLOCK_SIZE, _HOG_BLOCK_STRIDE,
            _HOG_CELL_SIZE, _HOG_NBINS
        )

    # ── Inference ────────────────────────────────────────────────────────────
    def detect(self, frame: np.ndarray) -> list[tuple[int, int, int, int, float]]:
        """
        Returns list of (x1, y1, x2, y2, score) for each plate detected.
        """
        if self.pipeline is not None:
            return self._detect_svm(frame)
        return self._detect_classical(frame)

    def _detect_svm(self, frame):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        h, w = gray.shape
        boxes, scores = [], []

        ww, wh = self.win_size
        for scale in SCALES:
            rw, rh = int(w * scale), int(h * scale)
            if rw < ww or rh < wh:
                break
            resized = cv2.resize(gray, (rw, rh))
            sx = max(1, int(STEP_X * scale))
            sy = max(1, int(STEP_Y * scale))
            for y in range(0, rh - wh, sy):
                for x in range(0, rw - ww, sx):
                    patch = resized[y:y + wh, x:x + ww]
                    feat  = self.hog.compute(patch).flatten().reshape(1, -1)
                    prob  = self.pipeline.predict_proba(feat)[0][1]
                    if prob >= SCORE_THRESH:
                        # Scale coords back to original size
                        x1 = int(x / scale); y1 = int(y / scale)
                        x2 = int((x + ww) / scale); y2 = int((y + wh) / scale)
                        boxes.append([x1, y1, x2, y2])
                        scores.append(float(prob))

        return self._nms(boxes, scores)

    def _detect_classical(self, frame):
        """Classical CV fallback: edge density + aspect ratio filtering."""
        gray    = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        blur    = cv2.bilateralFilter(gray, 13, 15, 15)
        edged   = cv2.Canny(blur, 30, 200)
        contours, _ = cv2.findContours(edged, cv2.RETR_TREE,
                                        cv2.CHAIN_APPROX_SIMPLE)
        contours = sorted(contours, key=cv2.contourArea, reverse=True)[:30]

        results = []
        for c in contours:
            peri  = cv2.arcLength(c, True)
            approx = cv2.approxPolyDP(c, 0.018 * peri, True)
            if len(approx) == 4:
                x, y, w, h = cv2.boundingRect(approx)
                ar = w / float(h) if h else 0
                if 1.5 <= ar <= 7.0 and w > 60 and h > 15:
                    results.append((x, y, x + w, y + h, 0.85))

        return results[:5]   # cap at 5 candidates

    @staticmethod
    def _nms(boxes, scores, iou_thresh=NMS_THRESH):
        if not boxes:
            return []
        boxes_arr  = np.array(boxes, dtype=np.float32)
        scores_arr = np.array(scores, dtype=np.float32)
        x1, y1, x2, y2 = (boxes_arr[:, i] for i in range(4))
        areas = (x2 - x1) * (y2 - y1)
        order = scores_arr.argsort()[::-1]
        keep  = []
        while order.size > 0:
            i = order[0]; keep.append(i)
            inter_x1 = np.maximum(x1[i], x1[order[1:]])
            inter_y1 = np.maximum(y1[i], y1[order[1:]])
            inter_x2 = np.minimum(x2[i], x2[order[1:]])
            inter_y2 = np.minimum(y2[i], y2[order[1:]])
            inter    = np.maximum(0, inter_x2 - inter_x1) * \
                       np.maximum(0, inter_y2 - inter_y1)
            iou      = inter / (areas[i] + areas[order[1:]] - inter + 1e-6)
            order    = order[np.where(iou <= iou_thresh)[0] + 1]
        return [(int(x1[i]), int(y1[i]), int(x2[i]), int(y2[i]),
                 float(scores_arr[i])) for i in keep]
