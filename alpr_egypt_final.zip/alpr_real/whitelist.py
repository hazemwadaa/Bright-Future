"""
Whitelist & Entry Log Module
=============================
Supports:
  - Text-based plate matching (e.g. "ABC1234")
  - Image-hash matching (for plates where OCR can't read Arabic script)
  - Combined confidence gating
"""

import os
import csv
import json
from datetime import datetime
from pathlib import Path


class WhitelistManager:
    def __init__(self, whitelist_path="whitelist/whitelist.json",
                 log_path="logs/entry_log.csv"):
        self.whitelist_path = Path(whitelist_path)
        self.log_path = Path(log_path)
        self.whitelist = {}     # plate_text → {owner, notes, hashes:[]}
        self.hash_index = {}    # plate_hash → plate_text
        self._load()
        self._init_log()

    def _load(self):
        self.whitelist_path.parent.mkdir(parents=True, exist_ok=True)
        if self.whitelist_path.exists():
            with open(self.whitelist_path) as f:
                data = json.load(f)
            self.whitelist = data
        else:
            self.whitelist = {
                "ABC1234": {"owner": "Admin",    "notes": "Demo plate", "hashes": []},
                "XYZ9999": {"owner": "Security", "notes": "Guard vehicle", "hashes": []},
                "TEST000": {"owner": "Test",     "notes": "Test plate",  "hashes": []},
            }
            self._save()
        self._rebuild_hash_index()

    def _save(self):
        with open(self.whitelist_path, "w") as f:
            json.dump(self.whitelist, f, indent=2, ensure_ascii=False)

    def _rebuild_hash_index(self):
        self.hash_index = {}
        for plate, meta in self.whitelist.items():
            for h in meta.get("hashes", []):
                self.hash_index[h] = plate

    def add_plate(self, plate, owner="", notes="", plate_hash=""):
        plate = plate.strip().upper()
        if not plate:
            return False
        if plate not in self.whitelist:
            self.whitelist[plate] = {"owner": owner, "notes": notes, "hashes": []}
        else:
            if owner:
                self.whitelist[plate]["owner"] = owner
            if notes:
                self.whitelist[plate]["notes"] = notes
        if plate_hash and plate_hash not in self.whitelist[plate]["hashes"]:
            self.whitelist[plate]["hashes"].append(plate_hash)
            self.hash_index[plate_hash] = plate
        self._save()
        return True

    def add_hash_to_plate(self, plate, plate_hash):
        """Associate a new image hash with an existing plate entry."""
        plate = plate.strip().upper()
        if plate in self.whitelist and plate_hash:
            if plate_hash not in self.whitelist[plate]["hashes"]:
                self.whitelist[plate]["hashes"].append(plate_hash)
                self.hash_index[plate_hash] = plate
                self._save()

    def remove_plate(self, plate):
        plate = plate.strip().upper()
        if plate in self.whitelist:
            for h in self.whitelist[plate].get("hashes", []):
                self.hash_index.pop(h, None)
            del self.whitelist[plate]
            self._save()
            return True
        return False

    def is_whitelisted(self, plate="", plate_hash=""):
        if plate and plate.strip().upper() in self.whitelist:
            return True
        if plate_hash and plate_hash in self.hash_index:
            return True
        return False

    def resolve_plate(self, plate="", plate_hash=""):
        """Return canonical plate string for a text or hash lookup."""
        if plate and plate.strip().upper() in self.whitelist:
            return plate.strip().upper()
        if plate_hash and plate_hash in self.hash_index:
            return self.hash_index[plate_hash]
        return plate.strip().upper() if plate else "UNKNOWN"

    def get_owner(self, plate):
        info = self.whitelist.get(plate.strip().upper(), {})
        return info.get("owner", "Unknown")

    def all_plates(self):
        return [
            {"plate": p, "owner": m.get("owner",""), "notes": m.get("notes",""),
             "hashes": len(m.get("hashes",[]))}
            for p, m in self.whitelist.items()
        ]

    def _init_log(self):
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.log_path.exists():
            with open(self.log_path, "w", newline="") as f:
                csv.writer(f).writerow([
                    "timestamp", "plate", "confidence",
                    "status", "owner", "gate_action", "source", "hash"
                ])

    def log_event(self, plate, confidence, status, gate_action,
                  source="camera", plate_hash=""):
        owner = self.get_owner(plate) if status == "GRANTED" else "—"
        row = [
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            plate, f"{confidence:.2f}", status,
            owner, gate_action, source, plate_hash[:8] if plate_hash else ""
        ]
        with open(self.log_path, "a", newline="") as f:
            csv.writer(f).writerow(row)
        return row

    def recent_events(self, n=200):
        if not self.log_path.exists():
            return []
        with open(self.log_path, newline="") as f:
            rows = list(csv.DictReader(f))
        return rows[-n:][::-1]

    def check_and_trigger(self, plate, confidence, source="camera",
                          plate_hash=""):
        if confidence < 0.25 and not plate_hash:
            return {"status": "LOW_CONFIDENCE", "gate_action": "HOLD",
                    "owner": "—", "plate": plate, "confidence": confidence}

        granted = self.is_whitelisted(plate=plate, plate_hash=plate_hash)
        canonical = self.resolve_plate(plate=plate, plate_hash=plate_hash)
        status = "GRANTED" if granted else "DENIED"
        action = "OPEN"    if granted else "LOCKED"
        owner  = self.get_owner(canonical)

        self.log_event(canonical, confidence, status, action,
                       source, plate_hash)
        return {
            "plate":       canonical,
            "status":      status,
            "gate_action": action,
            "owner":       owner,
            "confidence":  confidence,
            "hash":        plate_hash,
        }
