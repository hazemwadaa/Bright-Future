"""
ALPR Training Module
====================
Trains a plate localization model from YOLO-format labeled data.
Uses a sliding-window HOG + SVM approach (fully offline, no GPU needed).
Also exports model to a format used by the detector at runtime.

Usage:
    python train.py --data ./data --output ./models
"""

import os
import sys
import glob
import argparse
import pickle
import json
import time
import cv2
import numpy as np
from pathlib import Path
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split

# ── HOG feature extractor settings ────────────────────────────────────────────
HOG_WIN_SIZE    = (64, 32)   # (W, H) — typical plate aspect ratio
HOG_BLOCK_SIZE  = (16, 16)
HOG_BLOCK_STRIDE= (8, 8)
HOG_CELL_SIZE   = (8, 8)
HOG_NBINS       = 9
NEG_PER_IMAGE   = 20        # random negative patches per training image
POS_SCALE_RANGE = (0.8, 1.2) # jitter for positive samples


def yolo_to_bbox(cx, cy, w, h, img_w, img_h):
    """Convert YOLO normalised [cx,cy,w,h] → pixel [x1,y1,x2,y2]."""
    x1 = int((cx - w / 2) * img_w)
    y1 = int((cy - h / 2) * img_h)
    x2 = int((cx + w / 2) * img_w)
    y2 = int((cy + h / 2) * img_h)
    return max(0, x1), max(0, y1), min(img_w, x2), min(img_h, y2)


def extract_hog(roi):
    """Resize ROI to HOG window size and compute HOG descriptor."""
    roi_resized = cv2.resize(roi, HOG_WIN_SIZE)
    hog = cv2.HOGDescriptor(
        HOG_WIN_SIZE, HOG_BLOCK_SIZE, HOG_BLOCK_STRIDE,
        HOG_CELL_SIZE, HOG_NBINS
    )
    return hog.compute(roi_resized).flatten()


def load_dataset(data_dir):
    """
    Loads YOLO-format dataset from data_dir/images and data_dir/labels.
    Returns X (HOG features), y (0/1 labels).
    """
    images_dir = Path(data_dir) / "images"
    labels_dir = Path(data_dir) / "labels"

    if not images_dir.exists() or not labels_dir.exists():
        print(f"[ERROR] Expected {images_dir} and {labels_dir} to exist.")
        sys.exit(1)

    img_paths = sorted(glob.glob(str(images_dir / "*.jpg")) +
                       glob.glob(str(images_dir / "*.png")) +
                       glob.glob(str(images_dir / "*.jpeg")))

    if not img_paths:
        print("[ERROR] No images found in images directory.")
        sys.exit(1)

    print(f"[INFO] Found {len(img_paths)} images.")
    X, y = [], []
    np.random.seed(42)

    for img_path in img_paths:
        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        if img is None:
            continue
        img_h, img_w = img.shape
        label_path = labels_dir / (Path(img_path).stem + ".txt")

        # ── Positive samples ─────────────────────────────────────────────────
        if label_path.exists():
            with open(label_path) as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) < 5:
                        continue
                    _, cx, cy, w, h = map(float, parts[:5])
                    x1, y1, x2, y2 = yolo_to_bbox(cx, cy, w, h, img_w, img_h)
                    roi = img[y1:y2, x1:x2]
                    if roi.size == 0:
                        continue
                    # Augment: flip + slight scale jitter
                    for scale in np.linspace(*POS_SCALE_RANGE, 3):
                        rw = max(1, int((x2 - x1) * scale))
                        rh = max(1, int((y2 - y1) * scale))
                        roi_aug = cv2.resize(roi, (rw, rh))
                        feat = extract_hog(roi_aug)
                        X.append(feat); y.append(1)
                    # Flip
                    feat_flip = extract_hog(cv2.flip(roi, 1))
                    X.append(feat_flip); y.append(1)

        # ── Negative samples (random patches not overlapping plates) ─────────
        for _ in range(NEG_PER_IMAGE):
            pw = np.random.randint(30, img_w // 3)
            ph = np.random.randint(15, img_h // 3)
            px = np.random.randint(0, max(1, img_w - pw))
            py = np.random.randint(0, max(1, img_h - ph))
            neg_roi = img[py:py + ph, px:px + pw]
            if neg_roi.size == 0:
                continue
            feat = extract_hog(neg_roi)
            X.append(feat); y.append(0)

    print(f"[INFO] Samples — positives: {y.count(1)}, negatives: {y.count(0)}")
    return np.array(X, dtype=np.float32), np.array(y)


def train(data_dir, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    print("[INFO] Loading dataset …")
    X, y = load_dataset(data_dir)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    print("[INFO] Training SVM classifier …")
    pipeline = Pipeline([
        ("scaler", StandardScaler()),
        ("svm",    SVC(kernel="rbf", C=10, gamma="scale",
                       probability=True, class_weight="balanced"))
    ])

    t0 = time.time()
    pipeline.fit(X_train, y_train)
    elapsed = time.time() - t0
    print(f"[INFO] Training done in {elapsed:.1f}s")

    y_pred = pipeline.predict(X_test)
    print("\n── Evaluation ────────────────────────────────")
    print(classification_report(y_test, y_pred,
                                 target_names=["background", "plate"]))

    model_path = Path(output_dir) / "plate_detector.pkl"
    with open(model_path, "wb") as f:
        pickle.dump(pipeline, f)

    meta = {
        "hog_win_size":     list(HOG_WIN_SIZE),
        "hog_block_size":   list(HOG_BLOCK_SIZE),
        "hog_block_stride": list(HOG_BLOCK_STRIDE),
        "hog_cell_size":    list(HOG_CELL_SIZE),
        "hog_nbins":        HOG_NBINS,
        "train_samples":    len(X_train),
        "test_samples":     len(X_test),
    }
    with open(Path(output_dir) / "model_meta.json", "w") as f:
        json.dump(meta, f, indent=2)

    print(f"\n[OK] Model saved → {model_path}")
    return str(model_path)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data",   default="./data",   help="Dataset root dir")
    ap.add_argument("--output", default="./models", help="Output model dir")
    args = ap.parse_args()
    train(args.data, args.output)
